import { Component } from '@angular/core';

@Component({
  selector: 'app-rental-history',
  templateUrl: './rental-history.component.html',
  styleUrl: './rental-history.component.css'
})
export class RentalHistoryComponent {

}
