import { Component } from '@angular/core';

@Component({
  selector: 'app-summary-view',
  templateUrl: './summary-view.component.html',
  styleUrl: './summary-view.component.css'
})
export class SummaryViewComponent {

}
